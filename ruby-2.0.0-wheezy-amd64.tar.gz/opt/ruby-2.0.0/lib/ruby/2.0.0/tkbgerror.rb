#
#   tkbgerror.rb - load tk/bgerror.rb
#
require 'tk/bgerror'
